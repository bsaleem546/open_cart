<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> - The Twins Furniture</title>

    <!-- Scripts -->


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->


    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('public/assets')); ?>/images/favicon.png">
    <link rel="stylesheet" href="<?php echo e(url('public/assets')); ?>/vendor/owl-carousel/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(url('public/assets')); ?>/vendor/owl-carousel/css/owl.theme.default.min.css">
    <link href="<?php echo e(url('public/assets')); ?>/vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
    <link href="<?php echo e(url('public/assets')); ?>/css/style.css" rel="stylesheet">

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>

<!--*******************
        Preloader start
    ********************-->
<div id="preloader">
    <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
    </div>
</div>
<!--*******************
    Preloader end
********************-->


    <div id="app">
        <div id="main-wrapper">

            <!--**********************************
                Nav header start
            ***********************************-->
            <div class="nav-header">
                <a href="<?php echo e(url('/')); ?>" class="brand-logo">
                    <img class="logo-abbr" src="<?php echo e(url('public/assets')); ?>/images/logo.png" alt="">
                    <img class="logo-compact" src="<?php echo e(url('public/assets')); ?>/images/logo-text.png" alt="">
                    <img class="brand-title" src="<?php echo e(url('public/assets')); ?>/images/logo-text.png" alt="">
                </a>

                <div class="nav-control">
                    <div class="hamburger">
                        <span class="line"></span><span class="line"></span><span class="line"></span>
                    </div>
                </div>
            </div>
            <!--**********************************
                Nav header end
            ***********************************-->

            <!--**********************************
                Header start
            ***********************************-->
            <div class="header">
                <div class="header-content">
                    <nav class="navbar navbar-expand">
                        <div class="collapse navbar-collapse justify-content-between">
                            <div class="header-left">

                            </div>

                            <ul class="navbar-nav header-right">
                                <li class="nav-item dropdown notification_dropdown">
                                    <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                        <i class="mdi mdi-bell"></i>
                                        <div class="pulse-css"></div>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <ul class="list-unstyled">
                                            <li class="media dropdown-item">
                                                <span class="success"><i class="ti-user"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong>Martin</strong> has added a <strong>customer</strong> Successfully
                                                        </p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                        </ul>
                                        <a class="all-notification" href="#">See all notifications <i
                                                class="ti-arrow-right"></i></a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown header-profile">
                                    <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                        <i class="mdi mdi-account"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a href="#" class="dropdown-item">
                                            <i class="icon-user"></i>
                                            <span class="ml-2">Profile </span>
                                        </a>
                                        <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <i class="icon-key"></i>
                                            <span class="ml-2">Logout </span>
                                        </a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <!--**********************************
                Header end ti-comment-alt
            ***********************************-->

            <!--**********************************
                Sidebar start
            ***********************************-->
            <div class="quixnav">
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!--**********************************
                Sidebar end
            ***********************************-->

            <!--**********************************
                Content body start
            ***********************************-->
            <div class="content-body">
                <!-- row -->
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!--**********************************
                Content body end
            ***********************************-->

        </div>


    </div>


<script src="<?php echo e(url('public/assets')); ?>/vendor/global/global.min.js"></script>
<script src="<?php echo e(url('public/assets')); ?>/js/quixnav-init.js"></script>
<script src="<?php echo e(url('public/assets')); ?>/js/custom.min.js"></script>


<!-- Vectormap -->
<script src="<?php echo e(url('public/assets')); ?>/vendor/raphael/raphael.min.js"></script>
<script src="<?php echo e(url('public/assets')); ?>/vendor/morris/morris.min.js"></script>


<script src="<?php echo e(url('public/assets')); ?>/vendor/circle-progress/circle-progress.min.js"></script>
<script src="<?php echo e(url('public/assets')); ?>/vendor/chart.js/Chart.bundle.min.js"></script>

<script src="<?php echo e(url('public/assets')); ?>/vendor/gaugeJS/dist/gauge.min.js"></script>

<!--  flot-chart js -->
<script src="<?php echo e(url('public/assets')); ?>/vendor/flot/jquery.flot.js"></script>
<script src="<?php echo e(url('public/assets')); ?>/vendor/flot/jquery.flot.resize.js"></script>

<!-- Owl Carousel -->
<script src="<?php echo e(url('public/assets')); ?>/vendor/owl-carousel/js/owl.carousel.min.js"></script>

<!-- Counter Up -->
<script src="<?php echo e(url('public/assets')); ?>/vendor/jqvmap/js/jquery.vmap.min.js"></script>
<script src="<?php echo e(url('public/assets')); ?>/vendor/jqvmap/js/jquery.vmap.usa.js"></script>
<script src="<?php echo e(url('public/assets')); ?>/vendor/jquery.counterup/jquery.counterup.min.js"></script>



<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\oc\resources\views/layouts/app.blade.php ENDPATH**/ ?>