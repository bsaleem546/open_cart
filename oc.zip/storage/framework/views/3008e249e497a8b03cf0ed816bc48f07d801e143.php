<?php $__env->startSection('title', 'Products'); ?>


<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(url('public/assets')); ?>/vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="stylesheet" href="<?php echo e(url('public/assets')); ?>/vendor/toastr/css/toastr.min.css">

    <style>
        tbody tr{
            color: black !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All Products</h4>
                    <div class="card-toolbar">
                        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-outline-primary">Add New</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="display" style="min-width: 845px">
                            <thead>
                            <tr>
                                <th>Brand</th>
                                <th>Category</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>In Stock</th>
                                <th>Start date</th>
                                <th>Options</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($products->brand); ?></td>
                                    <td><?php echo e($products->category); ?></td>
                                    <td><?php echo e($products->name); ?></td>
                                    <td><?php echo e($products->slug); ?></td>
                                    <td><?php echo e($products->quantity); ?></td>
                                    <td><?php echo e($products->price); ?></td>
                                    <td><?php echo e($products->in_stock == 1 ? 'Yes' : 'No'); ?></td>
                                    <td><?php echo e($products->created_at); ?></td>
                                    <td><a href="<?php echo e(route('products.edit', $products->id)); ?>"><i class="fas fa-cog"></i></a>
                                        |
                                        <a href="#" onclick="_delete( <?php echo e(json_encode($products)); ?> )"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="delete_modal" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Are you sure?</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5><span id="username"></span> once deleted cannot be restored.</h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="delete">Delete</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Datatable -->
    <script src="<?php echo e(url('public/assets')); ?>/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(url('public/assets')); ?>/js/plugins-init/datatables.init.js"></script>
    <script src="<?php echo e(url('public/assets')); ?>/vendor/toastr/js/toastr.min.js"></script>
    <script src="<?php echo e(url('public')); ?>/js/my-js.js"></script>

    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function _delete(data) {
            $('#username').html(data.name)
            $('#delete_modal').modal('show')
            document.getElementById('delete').addEventListener('click', (e) => {
                $.ajax({
                    type: 'DELETE',
                    url: main_url+'admin/products/'+data.id,
                    contentType: false,
                    processData: false,
                    // headers:$('meta[name="csrf-token"]').attr('content'),
                }).done(function(response){
                    $('#delete_modal').modal('hide')
                    if(response.status == true){
                        toast_success(response.message)
                        setTimeout(function(){ window.location = response.redirect; }, 3000);
                    }else{
                        $('#delete_modal').modal('hide')
                        toast_error(response.message)
                        console.log(response.details)
                    }
                });
            })
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oc\resources\views/admin/products/index.blade.php ENDPATH**/ ?>