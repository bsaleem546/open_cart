<?php $__env->startSection('title', 'Add Options'); ?>

<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" href="<?php echo e(url('public/assets')); ?>/vendor/toastr/css/toastr.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Add New</h4>
                </div>
                <div class="card-body">
                    <div class="basic-form">
                        <?php echo e(Form::open([
                            'route' => 'options.store',
                            'class' => '',
                            'id' => 'created'
                        ])); ?>

                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label col-form-label-lg">Attribute</label>
                                <div class="col-sm-10">
                                    <?php echo e(Form::select('attribute_id', \App\Models\Attributes::pluck('name','id'), null, [
                                        'required'=>'required', 'class' => 'form-control form-control-lg', 'placeholder'=>'Select Please'])); ?>

                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label col-form-label-lg">Name</label>
                                <div class="col-sm-10">
                                    <input name="name" type="text" required
                                           class="form-control form-control-lg" placeholder="Name">
                                </div>
                            </div>























                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label col-form-label-lg"></label>
                                <div class="col-sm-10">
                                    <input type="submit" value="Create" class="btn btn-primary">
                                </div>
                            </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Toastr -->
    <script src="<?php echo e(url('public/assets')); ?>/vendor/toastr/js/toastr.min.js"></script>
    <script src="<?php echo e(url('public')); ?>/js/my-js.js"></script>
    <script>

        $(document).on('submit', '#created', (event) => {

            event.preventDefault();
            var form = $('#created');
            var formData = new FormData(form[0]);
            $.ajax({
                type: form.attr('method'),
                url: form.attr('action'),
                contentType: false,
                processData: false,
                dataType: 'json',
                headers:$('meta[name="csrf-token"]').attr('content'),
                data: formData,
            }).done(function(response){
                if(response.status == true){
                    toast_success(response.message)
                    setTimeout(function(){ window.location = response.redirect; }, 3000);
                }else{
                    toast_error(response.message)
                    console.log(response.details)
                }
            });
        })


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oc\resources\views/admin/options/create.blade.php ENDPATH**/ ?>