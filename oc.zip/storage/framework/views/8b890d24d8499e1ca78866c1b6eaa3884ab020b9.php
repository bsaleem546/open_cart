<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(url('public/assets')); ?>/vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="stylesheet" href="<?php echo e(url('public/assets')); ?>/vendor/toastr/css/toastr.min.css">

    <style>
        tbody tr{
            color: black !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All Orders</h4>
                    <div class="card-toolbar">

                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="display" style="min-width: 845px">
                            <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Sub Total</th>
                                <th>Discount</th>
                                <th>Discount Code</th>
                                <th>Shipping</th>
                                <th>Total</th>
                                <th>Note</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($orders->id); ?></td>
                                    <td><?php echo e($orders->sub_total); ?></td>
                                    <td><?php echo e($orders->discount); ?></td>
                                    <td><?php echo e($orders->discount_code); ?></td>
                                    <td><?php echo e($orders->shipping); ?></td>
                                    <td><?php echo e($orders->total); ?></td>
                                    <td><?php echo e($orders->note); ?></td>
                                    <td><?php echo e($orders->status); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($orders->created_at)->format('d-m-Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('orders.details', [$orders->id])); ?>" class="btn btn-outline-primary">View Details</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Datatable -->
    <script src="<?php echo e(url('public/assets')); ?>/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(url('public/assets')); ?>/js/plugins-init/datatables.init.js"></script>
    <script src="<?php echo e(url('public/assets')); ?>/vendor/toastr/js/toastr.min.js"></script>
    <script src="<?php echo e(url('public')); ?>/js/my-js.js"></script>

    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/twinsfurniture/staging.thetwinsfurnitures.com/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>