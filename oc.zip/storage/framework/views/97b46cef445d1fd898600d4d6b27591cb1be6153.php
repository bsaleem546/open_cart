<?php $__env->startSection('title', 'Order Details'); ?>

<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(url('public/assets')); ?>/vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="stylesheet" href="<?php echo e(url('public/assets')); ?>/vendor/toastr/css/toastr.min.css">

    <style>
        tbody tr{
            color: black !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Order Details</h4>
                    <div class="card-toolbar">
                    </div>
                </div>

                <div class="card-body">
                    <div>
                        <h4>Product details</h4>
                            <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h6>Product Name: </h6>
                                <p class="font-weight-bold text-black-50"><?php echo e($op->product->name); ?></p>
                                <h6>Qty: </h6>
                                <p class="font-weight-bold text-black-50"><?php echo e($op->quantity); ?></p>
                                <h6>Attributes: </h6>
                                <p class="font-weight-bold text-black-50"><?php echo e($op->attr); ?></p>
                                <h6>Total: </h6>
                                <p class="font-weight-bold text-black-50"><?php echo e($op->total); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <hr>

                        <h4>Customer Details</h4>
                        <h6>Email:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($customer->email); ?></p>
                        <h6>Name:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($customer->fname.' '.$customer->lname); ?></p>
                        <h6>Address:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($customer->address); ?></p>
                        <h6>City:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($customer->city); ?></p>
                        <h6>Country:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($customer->country); ?></p>
                        <h6>Phone:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($customer->phone); ?></p>

                        <hr>

                        <h4>Order Summary</h4>
                        <h6>Sub Total:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($order->sub_total); ?></p>
                        <h6>Discount:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($order->discount); ?></p>
                        <h6>Discount Code:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($order->discount_code); ?></p>
                        <h6>Shipping:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($order->shipping); ?></p>
                        <h6>Total:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($order->total); ?></p>
                        <h6>Note:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($order->note); ?></p>
                        <h6>Status:</h6>
                            <p class="font-weight-bold text-black-50"><?php echo e($order->status); ?></p>

                        <hr>
                        <h4>Change order status</h4>
                        <form action="<?php echo e(route('orders.status')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                            <select name="order_status" class="form-control form-control-lg" required>
                                <option value="">Select status</option>
                                <option value="PENDING">Pending</option>
                                <option value="IN-PROCESS">In Process</option>
                                <option value="COMPLETED">Completed</option>
                                <option value="DELIVERED">Delivered</option>
                            </select>
                            <input type="submit" value="Submit" class="btn btn-primary" style="margin-top: 20px">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/twinsfurniture/staging.thetwinsfurnitures.com/resources/views/admin/orders/details.blade.php ENDPATH**/ ?>