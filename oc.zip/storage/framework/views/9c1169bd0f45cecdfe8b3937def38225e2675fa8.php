<?php $__env->startSection('title', 'Add Products'); ?>

<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" href="<?php echo e(url('public/assets')); ?>/vendor/toastr/css/toastr.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="app">
        <add-product :Cbrands="<?php echo e($brands); ?>" :Ccategories="<?php echo e($categories); ?>"></add-product>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Toastr -->
    <script src="<?php echo e(url('public/assets')); ?>/vendor/toastr/js/toastr.min.js"></script>
    <script src="<?php echo e(url('public')); ?>/js/my-js.js"></script>
    <script src="<?php echo e(url('public')); ?>/js/app.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oc\resources\views/admin/products/create.blade.php ENDPATH**/ ?>