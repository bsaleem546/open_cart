<?php $__env->startSection('title', $category['name']); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="mt-contact-banner style4" style="background-color: #F6F6F6">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 text-center">
                    <h1><?php echo e($category['name']); ?></h1>
                    <!-- Breadcrumbs of the Page -->
                    <nav class="breadcrumbs">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(url('/')); ?>">Home <i class="fa fa-angle-right"></i></a></li>
                            <li><a href="<?php echo e(url('/categories')); ?>">Category <i class="fa fa-angle-right"></i></a></li>
                            <li><?php echo e($category['name']); ?></li>
                        </ul>
                    </nav>
                    <!-- Breadcrumbs of the Page end -->
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="row">
            <!-- sidebar of the Page start here -->
            <aside id="sidebar" class="col-xs-12 col-sm-4 col-md-3 wow fadeInLeft"
                   data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInLeft;">
                <!-- shop-widget filter-widget of the Page start here -->

                <!-- shop-widget of the Page start here -->
                <section class="shop-widget">
                    <h2>CATEGORIES</h2>
                    <!-- category list start here -->
                    <ul class="list-unstyled category-list">
                        <?php $__currentLoopData = \App\Models\Category::orderBy('created_at')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('categories/'.$c->slug)); ?>">
                                    <span class="name"><?php echo e($c->name); ?></span>
                                    <span class="num"> <?php echo e(count($c->products)); ?> </span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <!-- category list end here -->
                </section>
                <!-- shop-widget of the Page end here -->

                <!-- shop-widget of the Page start here -->
                <section class="shop-widget">
                    <h2>HOT SALE</h2>
                    <?php $__currentLoopData = \App\Models\Product::where('sale_price', '>', 0)->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-product4 mt-paddingbottom20">
                            <div class="img">
                                <a href="<?php echo e(url('products/'.$sp->slug)); ?>">

                                    <?php if($sp->singleImages->isEmpty()): ?>
                                        <img src="<?php echo e(url('public/imgs/empty.jpg')); ?>" alt="image description" style="width: 80px; height: 80px">
                                    <?php else: ?>
                                        <?php $__currentLoopData = $sp->singleImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e(url('public/uploads/'.$i->paths)); ?>" alt="image description" style="width: 80px; height: 80px">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="text">
                                <div class="frame">
                                    <strong><a href="<?php echo e(url('products/'.$sp->slug)); ?>"><?php echo e($sp->name); ?></a></strong>
                                    <ul class="mt-stars">
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star-o"></i></li>
                                    </ul>
                                </div>
                                <del class="off">$<?php echo e($sp->price); ?></del>
                                <span class="price">$<?php echo e($sp->sale_price); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </section><!-- shop-widget of the Page end here -->
            </aside><!-- sidebar of the Page end here -->

            <div class="col-xs-12 col-sm-8 col-md-9 wow fadeInRight" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInRight;">
                <header class="mt-shoplist-header"></header>
                <!-- mt productlisthold start here -->
                <ul class="mt-productlisthold list-inline">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <!-- mt product1 large start here -->
                            <div class="mt-product1 large">
                                <div class="box">
                                    <div class="b1">
                                        <div class="b2">
                                            <a href="<?php echo e(url('products/'.$p->slug)); ?>">
                                                <?php if($p->singleImages->isEmpty()): ?>
                                                    <img src="<?php echo e(url('public/imgs/empty.jpg')); ?>" alt="image description">
                                                <?php else: ?>
                                                    <?php $__currentLoopData = $p->singleImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <img src="<?php echo e(url('public/uploads/'.$i->paths)); ?>" alt="image description" style="width: 303px; height: 303px">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </a>
                                            <?php if($p->sale_price > 0): ?>
                                                <span class="caption">
                                                    <span class="new">Sell</span>
                                                </span>
                                            <?php endif; ?>
                                            <ul class="links">
                                                <li><a href="javascript:void(0)" onclick="cart(<?php echo e($p); ?>)"><i class="icon-handbag"></i><span>Add to Cart</span></a></li>
                                                <?php $wishlist = \Illuminate\Support\Facades\Session::get('wishlist') ?>
                                                <?php if( isset($wishlist[$p->id]) ): ?>
                                                    <li><a href="javascript:void(0)" onclick="wishlist(<?php echo e($p->id); ?>)"><i class="fa fa-heart" style="color: #FBA421"></i></a></li>
                                                <?php else: ?>
                                                    <li><a href="javascript:void(0)" onclick="wishlist(<?php echo e($p->id); ?>)"><i class="icomoon icon-heart-empty"></i></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="txt">
                                    <strong class="title"><a href="<?php echo e(url('products/'.$p->slug)); ?>"><?php echo e($p->name); ?></a></strong>
                                    <?php if($p->has_attributes == 1): ?>
                                        <span class="price"> <span>
                                                $<?php echo e($p->variation_values->min('price')); ?> - $<?php echo e($p->variation_values->max('price')); ?>

                                        </span></span>
                                    <?php else: ?>
                                        <span class="price"> <span>$<?php echo e($p->sale_price > 0 ? $p->sale_price : $p->price); ?></span></span>
                                    <?php endif; ?>
                                </div>
                            </div><!-- mt product1 center end here -->
                        </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul><!-- mt productlisthold end here -->

                <div class="my-pagiantion">
                    <?php echo $products->links(); ?>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url('public/js/my-js.js')); ?>"></script>
    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function wishlist(id){
            $.ajax({
                type: 'GET',
                url: main_url + 'addToWishlist/'+id,
                dataType: 'JSON',
                success: (data) => {
                    if (data.status == true){
                        location.reload();
                    }
                }
            })
        }

        function cart(data) {
            var price = data.sale_price > 0 ? data.sale_price : data.price;
            $.ajax({
                type: 'POST',
                url: main_url+'addToCart',
                dataType: 'JSON',
                data: { id:data.id, qty:1, price:price, att:'' },
                success: (data) => {
                    if (data.status == true){
                        location.reload();
                    }
                },
                error: (err) => {},
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/twinsfurniture/staging.thetwinsfurnitures.com/resources/views/CategoryBySlug.blade.php ENDPATH**/ ?>