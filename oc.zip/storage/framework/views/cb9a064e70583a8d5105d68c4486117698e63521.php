<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?> - The Twins Furniture</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('public/assets')); ?>/images/favicon.png">
    <link href="<?php echo e(url('public/assets')); ?>/css/style.css" rel="stylesheet">

</head>

<body class="h-100">
<div class="authincation h-100" style="padding: 100px 0px;">

    <?php echo $__env->yieldContent('content'); ?>
</div>


<!--**********************************
    Scripts
***********************************-->
<!-- Required vendors -->
<script src="<?php echo e(url('public/assets')); ?>/vendor/global/global.min.js"></script>
<script src="<?php echo e(url('public/assets')); ?>/js/quixnav-init.js"></script>
<script src="<?php echo e(url('public/assets')); ?>/js/custom.min.js"></script>

</body>

</html>
<?php /**PATH /home2/twinsfurniture/staging.thetwinsfurnitures.com/resources/views/layouts/auth.blade.php ENDPATH**/ ?>